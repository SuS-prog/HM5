package com.example.hm5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.snackbar.Snackbar;

import java.util.Random;

public class TestResources extends AppCompatActivity {

    private boolean isSubscribed = true;

    private Button colorCahngeButton;
    private View mainLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_test_resources);
        String profileName = "@Andrew";
        setTitle("User's profile: " + profileName);

        Button buttonSubscribe = findViewById(R.id.subscribeButton);

        buttonSubscribe.setOnClickListener(view -> {
            if(isSubscribed){
                Snackbar snackbar = Snackbar.make(view,"Are you sure you want to unsubscribe from: " + profileName + "?", Snackbar.LENGTH_LONG)
                        .setAction("Yes, unsubscribe", v -> {
                            buttonSubscribe.setBackgroundColor(getResources().getColor(R.color.Unsubscribe_Button_color));
                            buttonSubscribe.setText("Subscribe");

                            isSubscribed = !isSubscribed;
                        });
                snackbar.show();
            } else {
                buttonSubscribe.setBackgroundColor(getResources().getColor(R.color.Subscribe_Button_color));
                buttonSubscribe.setText("Unsubscribe");

                Toast toast = Toast.makeText(getApplicationContext(), "You subscribed on " + profileName, Toast.LENGTH_SHORT);
                toast.show();

                isSubscribed = !isSubscribed;
            }
        });

        colorCahngeButton.findViewById(R.id.changeColorButton);
        mainLayout.findViewById(R.id.mainLayout);

        colorCahngeButton.setOnClickListener(view -> {changeBackgroundColor();});



    }

    private void changeBackgroundColor(){
        Random random = new Random();
        int color = android.graphics.Color.rgb(random.nextInt(256), random.nextInt(256), random.nextInt(256));
        mainLayout.setBackgroundColor(color);
    }

}